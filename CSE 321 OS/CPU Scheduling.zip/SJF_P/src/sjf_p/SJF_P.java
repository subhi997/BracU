package sjf_p;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class SJF_P {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        File file = new File("sjf_p.txt");
        BufferedReader br = new BufferedReader(new FileReader(file));
        int numberP = Integer.parseInt(br.readLine());
        Process [] p = new Process[numberP];
        int [] bTime = new int [numberP];
        int [] arrival = new int [numberP];
        int [] arrivalCheck = new int [numberP]; //checks whether a process arrives
        int totalT = 0; //calculates the total burst time of processes
        
        //creating objects of processes
        for(int i = 0; i < p.length; ++i){
            p[i] = new Process(); 
        }
        
        //spliting and assigning values in the arrays
        String st;
        int i = 0;
        while((st = br.readLine()) != null){
            String [] str = st.split(" ");
            p[i].id = str[0];
            bTime[i] = Integer.parseInt(str[1]);
            arrival[i] = Integer.parseInt(str[2]);
            ++i;
        }
        
        //assigning the burst time
        for(int j = 0; j < p.length; ++j){
            p[j].time = bTime[j];
            totalT += p[j].time;
        }
        
        //assigning the arrival time
        for(int j = 0; j < p.length; ++j){
            p[j].arrive = arrival[j];
        }
        
        
        //final preemptive printing
        for(int j = 0; j < totalT; ++j){
            for(int k = 0; k < p.length; ++k){
                if(p[k].arrive <= j){
                    arrivalCheck[k] = p[k].arrive;
                } else {
                    arrivalCheck[k] = 3000;
                }
            }
            Arrays.sort(arrivalCheck);
            /*
            //just checking with this loop
            for(int q = 0; q < arrivalCheck.length; ++q){ 
                System.out.print(arrivalCheck[q] + " ");
            } */
            System.out.print("At "+j+" second: ");
            int minBurst = 1000;
            String executingProcess = null;
            for(int k = 0; k < arrivalCheck.length; ++k){
                if(arrivalCheck[k] < 3000){
                    for(int pc = 0; pc < p.length; ++pc){
                        if(p[pc].arrive == arrivalCheck[k]){
                            if(p[pc].time < minBurst && p[pc].time > 0){
                                minBurst = p[pc].time;
                                executingProcess = p[pc].id;
                                //--p[pc].time;
                            }
                        }
                    }
                    
                }
            }
            //deducting burst time outside the loop so that only the final minimum gets reduced
            for(int count = 0; count < p.length; ++count){ 
                if(minBurst == p[count].time){
                    --p[count].time;
                }
            }
            //System.out.println(minBurst+" "+executingProcess);
            System.out.println(executingProcess);
            //System.out.println();
              
        }
        
        
        /*
        //checking
        for(int j = 0; j < p.length; ++j){
            System.out.print(p[j].arrive+" ");
            System.out.print(bTime[j]+" ");
            System.out.print(arrival[j]);
            System.out.println();
        }
        //System.out.println(totalT);
        /*
        //checking and printing the inputs
        String st;
        while((st = br.readLine()) != null){
            System.out.println(st);
        } */
    }
    
}
