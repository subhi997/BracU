package sjf_p;

public class Process {
    public String id;
    public int time;
    public int arrive;
    public int waitT;
    public int startT;
    public int endT;
    
}
