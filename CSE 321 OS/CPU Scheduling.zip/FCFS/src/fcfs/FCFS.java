package fcfs;

import java.util.Scanner;

public class FCFS {
    public static int waiting = 0;
    public static int waitingSum = 0;
    public static int turnaround = 0;
    public static int turnaroundSum = 0;
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Select Number of Process: ");
        int process = sc.nextInt();
        Process [] p = new Process[process];
        
        
        //creating objects of processes
        for(int i = 0; i < p.length; ++i){
            p[i] = new Process(); 
        }
        
        
        System.out.println("Process Time: ");
        //int [] processTime = new int[process];
        for(int i = 0; i < p.length; ++i){
            p[i].setTime(sc.nextInt());
        }
        
        //assigning id's
        for(int i = 0; i < p.length; ++i){
            p[i].id = i+1;
        }
        
        //waiting time caltulation
        for(int i = 0; i < p.length; ++i){
            p[i].waitT = waiting;
            waitingSum += waiting;
            p[i].startT = p[i].waitT;
            waiting += p[i].time;
        }
        
        //turnAround time caltulation
        for(int i = 0; i < p.length; ++i){
            turnaround += p[i].time;
            p[i].endT = turnaround;
            turnaroundSum += turnaround;
        }
        
        
        
        //printing 
        System.out.println("Id\t Time\t WaitT\t StartT\t EndT");
        System.out.println("---------------------------------------");
        for(int i = 0; i < p.length; ++i){
            System.out.println(p[i]);
        }
        System.out.println();
        System.out.println("Therefore, average waiting time = "+(waitingSum*(1.0)/process)+" msec");
        System.out.println("And, average turnaround time = "+(turnaroundSum*(1.0)/process)+" msec");
    }
}
