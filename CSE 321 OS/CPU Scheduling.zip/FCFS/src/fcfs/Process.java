package fcfs;

public class Process {
    public int id;
    public int time;
    public int waitT;
    public int startT;
    public int endT;
    
    public void setTime(int time){
        this.time = time;
    }
    public int getTime(){
        return time;
    }
    
    @Override
    public String toString(){
        return id+"\t "+time+"\t "+waitT+"\t "+startT+"\t "+endT;
    }
            
}
