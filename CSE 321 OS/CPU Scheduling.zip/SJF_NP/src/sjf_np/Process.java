package sjf_np;

public class Process {
    public String id;
    public int time;
    public int waitT;
    public int startT;
    public int endT;
    
    @Override
    public String toString(){
        return id+"\t "+time+"\t "+waitT+"\t "+startT+"\t "+endT;
    }
}
