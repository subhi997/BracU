package priority;

public class Process {
    public String id;
    public int time;
    public int priority;
    public int waitT;
    public int startT;
    public int endT;
    
    @Override
    public String toString(){
        return id+"\t "+time+"\t "+priority+"\t\t "+waitT+"\t "+startT+"\t "+endT;
    } 
}
