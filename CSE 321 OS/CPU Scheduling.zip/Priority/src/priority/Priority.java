package priority;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class Priority {
    public static int waiting = 0;
    public static int waitingSum = 0;
    public static int turnaround = 0;
    public static int turnaroundSum = 0;
    public static void main(String[] args) throws FileNotFoundException, IOException {
        File file = new File("priority.txt");
        BufferedReader br = new BufferedReader(new FileReader(file));
        int numberP = Integer.parseInt(br.readLine());
        Process [] p = new Process[numberP];
        int [] bTime = new int[numberP];
        int [] priority = new int[numberP];
        
        //creating objects of processes
        for(int i = 0; i < p.length; ++i){
            p[i] = new Process(); 
        }
        
        //spliting and assigning values in the arrays
        String st;
        int i = 0;
        while((st = br.readLine()) != null){
            
            String [] str = st.split(" ");
            p[i].id = str[0];
            bTime[i] = Integer.parseInt(str[1]);
            priority[i] = Integer.parseInt(str[2]);
            ++i;
        }
        
        //assigning burst time
        for(int j = 0; j < p.length; ++j){
            p[j].time = bTime[j];
        }
        
        //assigning priority
        for(int j = 0; j < p.length; ++j){
            p[j].priority = priority[j];
        }
        
        //sorting according to smallest burst time
        Arrays.sort(priority);
        /*
        for (int j = 0; j < priority.length; ++j){
            System.out.println(priority[j]+" ");
        } */
        
        //arranging the processes according to priority
        Process [] sequence = new Process[p.length];
        for(int j = 0; j < sequence.length; ++j){
            for(int k = 0; k < p.length; ++k){
                if(p[k].priority == priority[j]){
                    sequence[j] = p[k];
                    break;
                }
            }
        }
        
        //waiting time & start time
        for(int j = 0; j < sequence.length; ++j){
            sequence[j].waitT = waiting;
            waitingSum += waiting;
            sequence[j].startT = sequence[j].waitT;
            waiting += sequence[j].time;
        }
        
        //turnaround time
        for(int j = 0; j < sequence.length; ++j){
            turnaround += sequence[j].time;
            sequence[j].endT = turnaround;
            turnaroundSum += turnaround;
        }
        
        //printing 
        System.out.println("Id\t Time\t Priority\t WaitT\t StartT\t EndT");
        System.out.println("---------------------------------------------------");
        for(int j = 0; j < sequence.length; ++j){
            System.out.println(sequence[j]);
        }
        System.out.println();
        System.out.println("Therefore, average waiting time = "+(waitingSum*(1.0)/numberP)+" msec");
        System.out.println("And, average turnaround time = "+(turnaroundSum*(1.0)/numberP)+" msec");
        
        
        
        
        
        /*
        //checking
        for(int j = 0; j < p.length; ++j){
            System.out.print(p[j].time+" ");
            System.out.print(bTime[j]+" ");
            System.out.print(priority[j]);
            //System.out.println(sequence[i]);
            System.out.print(p[j].id+" ");
            System.out.print(p[j].priority+" ");
            System.out.println();
        }
        /*
        //checking input
        String st;
        while((st = br.readLine()) != null){
            System.out.println(st);
        }
        */
    }
    
}
