package roundrobin;

public class Process {
    public String id;
    public int time;
}
