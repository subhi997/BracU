package roundrobin;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class RoundRobin {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        File file = new File ("roundRobin.txt");
        BufferedReader br = new BufferedReader(new FileReader(file));
        int quantumT = Integer.parseInt(br.readLine());
        int numberP = Integer.parseInt(br.readLine());
        Process [] p = new Process[numberP];
        int [] bTime = new int [numberP];
        int totalT = 0; //calculates the total burst time of all processes
        
        //creating objects of processes
        for (int i = 0; i < p.length; ++i){
            p[i] = new Process();
        }
        
        //spliting and assigning values in the arrays
        String st;
        int i = 0;
        while((st = br.readLine()) != null){
            String [] str = st.split(" ");
            p[i].id = str[0];
            bTime[i] = Integer.parseInt(str[1]);
            ++i;
        }
        
        //assigning the burst time
        for (int j = 0; j < p.length; ++j){
            p[j].time = bTime[j];
            totalT += p[j].time;
        }
        
        //round-robin printing
        int processChange = 0;
        String executingProcess = null;
        int processCount = 0;
        for (int j = 0; j < totalT; ++j){
            if((p[processChange].time == 0) || (processCount == quantumT)){
                ++processChange;
                processCount = 0;
            }
            if(processChange == 3){
                processChange = 0;
            }
            if(processChange < 3){
                if(p[processChange].time > 0 && processCount < quantumT){
                    executingProcess = p[processChange].id;
                    --p[processChange].time;
                    ++processCount;
                } 
            }
            System.out.println("At "+j+" ms: "+executingProcess);
        }
        
    }
    
}
